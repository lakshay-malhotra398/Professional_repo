# Medical insurance premium prediction
# Group 3 - Assignment 1

# Libraries
import pandas as pd
import seaborn as sns
import matplotlib.pyplot as plt
from sklearn.preprocessing import StandardScaler
from sklearn.model_selection import train_test_split
from sklearn.ensemble import RandomForestRegressor

# Importing csv file to dataframe
df = pd.read_csv('Medicalpremium.csv')

# View top 5 records
print(df.head())
print('************************************************')

# view shape of the dataset
print('Number of rows in the dataset', df.shape[0])
print('Number of columns in the dataset', df.shape[1])
print('************************************************')

# View info of the dataset
df.info()
print('************************************************')

# Updating the  datatype for object variable
for i in df[['Diabetes', 'BloodPressureProblems', 'AnyTransplants', 'AnyChronicDiseases', 'KnownAllergies',
             'HistoryOfCancerInFamily', 'NumberOfMajorSurgeries']]:
    df[i] = df[i].astype('object')
print('************************************************')

# view info of the dataset to check whether the data type has been updated
df.info()
print('************************************************')

# check for null values
df.isnull().sum()
print('************************************************')

# check for duplicate values
dups = df.duplicated()
print('Number of duplicate records', dups.sum())
print('************************************************')

# Seprating the object and numeric variable
cat = []
num = []
for i in df.columns:
    if df[i].dtype == 'object':
        cat.append(i)
    else:
        num.append(i)

num, cat
print('************************************************')

# Summary of numeric data
df[num].describe().T
print('************************************************')

# Summary of object data
df[cat].describe().T
print('************************************************')


# View unique object values
for i in df[cat]:
    print(i, df[i].nunique())
    print(df[i].value_counts())
    print('************************************************')

# Checking for outliers in numeric data
for i in df[num]:
    fig, axes = plt.subplots(nrows=1,ncols=2, figsize=(8, 4))
    sns.histplot(df[i], kde=True,ax=axes[0], color='red')
    sns.boxplot(df[i], ax=axes[1],color='green')
    plt.show(block = True);

# Univariate analysis of numeric data
f, ax = plt.subplots(2, 2, figsize=(15, 15))
df.Age.plot.hist(bins = 20, edgecolor = 'black', color = 'green', ax=ax[0][0])
ax[0][0].set_title('Distribution of age among users')

df.PremiumPrice.plot.hist(bins = 25, edgecolor = 'black',color = 'pink', ax=ax[0][1])
ax[0][1].set_title('Distribution of PremiumPrice of users')

df.Height.plot.hist(bins = 25, edgecolor = 'black',color = 'red', ax=ax[1][0])
ax[1][0].set_title('Distribution of Height of users')

df.Weight.plot.hist(bins = 25, edgecolor = 'black',color = 'violet', ax=ax[1][1])
ax[1][1].set_title('Distribution of Weight of users')

print('Distribution of Age')
print('Oldest User was of:', round(df['Age'].max()), 'Years')
print('Youngest User was of:', round(df['Age'].min()), 'Years')
print('Average Use age:', round(df['Age'].mean()), 'Years')
print('**************************************************')

print('Distribution of Premium Price')
print('lowest Premium of a User was of:', round(df['PremiumPrice'].max()))
print('Youngest User was of:', round(df['PremiumPrice'].min()))
print('Average User Premium Price:', round(df['PremiumPrice'].mean()))
print('**************************************************')

print('Distribution of Height')
print('shortest Height of a User was of:', round(df['Height'].max()))
print('tallest User was of:', round(df['Height'].min()))
print('Average Height of  User:', round(df['Height'].mean()))
print('**************************************************')

print('Distribution of Weight')
print('Highest Weight of a User :', round(df['Weight'].max()))
print('Lowest weight of a User:', round(df['Weight'].min()))
print('Average Weight of a User:', round(df['Weight'].mean()))
print('**************************************************')
plt.show(block=True)

# Univariate analysis of object data

f, ax = plt.subplots(2,3,figsize=(10, 10))
df['Diabetes'].value_counts().plot.pie(explode=[0, 0.1], autopct='%1.1f%%', ax=ax[0][0])
df['AnyTransplants'].value_counts().plot.pie(explode=[0, 0.1], autopct='%1.1f%%', ax=ax[0][1])
df['AnyChronicDiseases'].value_counts().plot.pie(explode=[0, 0.1], autopct='%1.1f%%', ax=ax[0][2])
df['KnownAllergies'].value_counts().plot.pie(explode=[0, 0.1], autopct='%1.1f%%', ax=ax[1][0])
df['HistoryOfCancerInFamily'].value_counts().plot.pie(explode=[0, 0.1], autopct='%1.1f%%', ax=ax[1][1])
df['NumberOfMajorSurgeries'].value_counts().plot.pie(explode=[0, 0, 0, 0], autopct='%1.1f%%', ax=ax[1][2])
plt.show(block = True);


# Multivariate analysis

#Relation between Age and Premium Price
sns.lineplot(df['Age'], df['PremiumPrice'])
sns.lmplot(x='Age', y ='PremiumPrice', data=df)
plt.show(block = True);

#Relation between Weight and Premium Price
sns.lineplot(df['Weight'],df['PremiumPrice'])
sns.lmplot(x='Weight', y ='PremiumPrice',data=df)
plt.show(block = True);

# Relation between Height and Premium Price
sns.lineplot(df['Height'],df['PremiumPrice'])
sns.lmplot(x='Height', y ='PremiumPrice',data=df)
plt.show(block = True);

# Relation between Number Of Major Surgeries and Premium Price
f,ax=plt.subplots(1,2,figsize=(15,5))
sns.barplot(data = df, x='NumberOfMajorSurgeries',y='PremiumPrice',ax=ax[0])
sns.boxplot(data = df, x='NumberOfMajorSurgeries',y='PremiumPrice',ax=ax[1])
plt.show(block = True);

# Relation between History Of Cancer In Family and Premium Price
f,ax=plt.subplots(1,2,figsize=(15,5))
sns.barplot(data = df, x='HistoryOfCancerInFamily',y='PremiumPrice',ax=ax[0])
sns.boxplot(data = df, x='HistoryOfCancerInFamily',y='PremiumPrice',ax=ax[1])
plt.show(block = True);

# Relation between Known Allergies In Family and Premium Price
f,ax=plt.subplots(1,2,figsize=(15,5))
sns.barplot(data = df, x='KnownAllergies',y='PremiumPrice',ax=ax[0])
sns.boxplot(data = df, x='KnownAllergies',y='PremiumPrice',ax=ax[1])
plt.show(block = True);

# Relation between Any Chronic Diseases In Family and Premium Price
f,ax=plt.subplots(1,2,figsize=(15,5))
sns.barplot(data = df, x='AnyChronicDiseases',y='PremiumPrice',ax=ax[0])
sns.boxplot(data = df, x='AnyChronicDiseases',y='PremiumPrice',ax=ax[1])
plt.show(block = True);

# Relation between Any Transplants In Family and Premium Price
f,ax=plt.subplots(1,2,figsize=(15,5))
sns.barplot(data = df, x='AnyTransplants',y='PremiumPrice',ax=ax[0])
sns.boxplot(data = df, x='AnyTransplants',y='PremiumPrice',ax=ax[1])
plt.show(block = True);

# Relation between Diabetes In Family and Premium Price
f,ax=plt.subplots(1,2,figsize=(15,5))
sns.barplot(data = df, x='Diabetes',y='PremiumPrice',ax=ax[0])
sns.boxplot(data = df, x='Diabetes',y='PremiumPrice',ax=ax[1])
plt.show(block = True);

# Relation between Blood Pressure Problems In Family and Premium Price
f,ax=plt.subplots(1,2,figsize=(15,5))
sns.barplot(data = df, x='BloodPressureProblems',y='PremiumPrice',ax=ax[0])
sns.boxplot(data = df, x='BloodPressureProblems',y='PremiumPrice',ax=ax[1])
plt.show(block = True);

# Analyze the Premium Price by age according to the History Of Cancer In Family
sns.lmplot(x = 'Age', y = 'PremiumPrice', data=df, hue='HistoryOfCancerInFamily', palette='Set1')
plt.show(block = True);

# Analyze the Premium Price by age according to the Diabetes.
sns.lmplot(x = 'Age', y = 'PremiumPrice', data=df, hue='Diabetes', palette='Set2')
plt.show(block = True);

# Analyze the Premium Price by age according to the Any Transplants
sns.lmplot(x = 'Age', y = 'PremiumPrice', data=df, hue='AnyTransplants', palette='Set1')
plt.show(block = True);

# Analyze the Premium Price by age according to the Any Any Chronic Diseases
sns.lmplot(x = 'Age', y = 'PremiumPrice', data=df, hue='AnyChronicDiseases', palette='Set2')
plt.show(block = True);

# Analyze the Premium Price by age according to the Any Known Allergies
sns.lmplot(x = 'Age', y = 'PremiumPrice', data=df, hue='KnownAllergies', palette='Set1')
plt.show(block = True);

# Analyze the Premium Price by age according to the Number Of Major Surgeries
sns.lmplot(x = 'Age', y = 'PremiumPrice', data=df, hue='NumberOfMajorSurgeries')
plt.show(block = True);

# Analyze the Premium Price by age according to the Blood Pressure Problems
sns.lmplot(x = 'Age', y = 'PremiumPrice', data=df, hue='BloodPressureProblems', palette='Set1')
plt.show(block = True);

# Correlation Heatmap
sns.heatmap(df.corr(),annot=True,cmap='cool')
plt.show(block=True)

# Feature distribution for Prediction
X = df.drop('PremiumPrice',axis=1)
y = df.PremiumPrice

# Normalization
scalar =  StandardScaler()
X.Age = scalar.fit_transform(X[['Age']])
X.Height = scalar.fit_transform(X[['Height']])
X.Weight = scalar.fit_transform(X[['Weight']])

# Train and test data ( we use 75:25)
X_train,X_test,y_train,y_test = train_test_split(X, y, test_size=0.25, random_state=43)

# Modelling using Random forest regressor
Lr=RandomForestRegressor(n_estimators= 50,max_depth=5)
Lr_model=Lr.fit(X_train,y_train)

# Accuracy of Model
print('Accuracy of the model on training Dataset ',Lr_model.score(X_train, y_train))
print ('Accuracy of the model on Test Dataset ',Lr_model.score(X_test, y_test))

# Using feature importance to find import features
feature_imp = Lr_model.feature_importances_
sns.barplot(x=feature_imp, y=X.columns)
plt.xlabel('Importance Score')
plt.ylabel('Features')
plt.title("Important Features")
plt.show(block = True);













