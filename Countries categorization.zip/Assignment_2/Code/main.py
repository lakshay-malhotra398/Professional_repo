import numpy as np
import pandas as pd
import matplotlib.pyplot as plt
import seaborn as sns
from sklearn import metrics
from sklearn.cluster import KMeans
from sklearn.preprocessing import StandardScaler
import scipy.cluster.hierarchy as hcluster
from sklearn.cluster import AgglomerativeClustering

# Read CSV file
df = pd.read_csv('Country-data.csv')

# It will display the data-dictionary and Country-data values
print(df.head(5))

# Display column name and data type
print("\n Column names and data type\n")
df.info()

#Display statistical data
print(df.describe())

# Check whether any Empty/missing and duplicate values in final data
print("\n Missing/Empty values")
print(df.isna().sum())

print("\nDuplicate values:",df.duplicated().sum())

# As we are using unsupervised learning technique we are droping the country column from country data

final_df=df.drop(['country'],axis=1)
print(final_df.head(5))

#corelation matrix of data
corr_matrix=final_df.corr()
sns.heatmap(corr_matrix,annot=True)
plt.show(block=True)

#scaling the data
scaling=StandardScaler()
scaled=scaling.fit_transform(final_df)

scaled_df=pd.DataFrame(scaled,columns=final_df.columns)

# print scaled dataset
print(scaled_df.head(10))

#K-means algorithm Elbow method to find clusters


# plot elbow curve
a = []
K = range(1, 10)
for i in K:
    kmean = KMeans(n_clusters=i)
    kmean.fit(final_df)
    a.append(kmean.inertia_)

plt.plot(K, a, marker='o')
plt.title('Elbow Method', fontsize=15)
plt.xlabel('Number of clusters', fontsize=15)
plt.ylabel('Sum of Squared distance', fontsize=15)
plt.show(block=True)

#chosing no. of clusters as 3 and refitting kmeans model
kmeans = KMeans(n_clusters = 3,random_state = 111)
kmeans.fit(scaled_df)

#calculate Silhouette Coefficient for K=3
print(metrics.silhouette_score(scaled_df, kmeans.labels_))

#predict the values of country data
cluster_labels = kmeans.fit_predict(scaled_df)
preds = kmeans.labels_
kmeans_df = pd.DataFrame(df)
kmeans_df['KMeans_Clusters'] = preds
print(kmeans_df.head(10))

#Print the K-means prediction result in csv file
kmeans_df.to_csv('kmeans_result.csv')

#visulization of clusters
sns.scatterplot(kmeans_df['child_mort'],kmeans_df['gdpp'],hue='KMeans_Clusters',data=kmeans_df)
plt.title("Child Mortality vs gdpp", fontsize=15)
plt.xlabel("Child Mortality", fontsize=12)
plt.ylabel("gdpp", fontsize=12)
plt.show(block=True)

#visulization of clusters inflation vs gdpp
sns.scatterplot(kmeans_df['inflation'],kmeans_df['gdpp'],hue='KMeans_Clusters',data=kmeans_df)
plt.title("inflation vs gdpp", fontsize=15)
plt.xlabel("inflation", fontsize=12)
plt.ylabel("gdpp", fontsize=12)
plt.show(block=True)

#find number of developed country,developing country,under-developed country
k_under_developing=kmeans_df[kmeans_df['KMeans_Clusters']==0]['country']
k_developing=kmeans_df[kmeans_df['KMeans_Clusters']==1]['country']
k_developed=kmeans_df[kmeans_df['KMeans_Clusters']==2]['country']

k_under_developing.to_csv('kmeans_Under_developing.csv')
k_developing.to_csv('kmeans_developing.csv')
k_developed.to_csv('kmeans_developed.csv')

#Agglomerative Hierarchical Clustering


#plotting dendogram
plt.figure(figsize=(50, 12))
dend=hcluster.dendrogram(hcluster.linkage(scaled_df,method='ward'))
plt.show(block=True)

# Getting labels from Agglomearative Hierarchical clustering
hcluster = AgglomerativeClustering(n_clusters=3, affinity='euclidean', linkage='ward')
hcluster.fit_predict(scaled_df)
hcluster_label = hcluster.labels_
hcluster_df = pd.DataFrame(df)

#adding hcluster labels in hcluster_df
hcluster_df['hcluster'] = hcluster_label

#first few rows of hcluster_df
print(hcluster_df.head(10))
hcluster_df.to_csv('Comparison.csv')

#visulazing hcluster results
#child mortality vs exports
sns.scatterplot(hcluster_df['child_mort'],hcluster_df['gdpp'],hue='hcluster',data=hcluster_df)
plt.title("Child Mortality vs gdpp", fontsize=15)
plt.xlabel("Child Mortality", fontsize=12)
plt.ylabel("gdpp", fontsize=12)
plt.show(block=True)

#inflation vs gdpp
sns.scatterplot(hcluster_df['inflation'],hcluster_df['gdpp'],hue='hcluster',data=hcluster_df)
plt.title("Inflation vs gdpp", fontsize=15)
plt.xlabel("Inflation", fontsize=12)
plt.ylabel("gdpp", fontsize=12)
plt.show(block=True)

#find number of developed country,developing country,under-developed country
developed=hcluster_df[hcluster_df['hcluster']==0]['country']
developing=hcluster_df[hcluster_df['hcluster']==1]['country']
under_developing=hcluster_df[hcluster_df['hcluster']==2]['country']

under_developing.to_csv('hclust_Under_developing.csv')
developing.to_csv('hclust_developing.csv')
developed.to_csv('hclust_developed.csv')








