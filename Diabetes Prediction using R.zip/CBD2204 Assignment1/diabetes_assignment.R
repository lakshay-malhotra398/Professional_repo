library(car)
library(caret)
library(class)
library(dplyr)
library(ggplot2)
library(tidyr)
library(tidyverse)
library(performance)

install.packages("magrittr") # package installations are only needed the first time you use it
install.packages("dplyr") 
library(magrittr) # needs to be run every time you start R and want to use %>%
library(dplyr) 

#data collection from csv file
diabetes <- read.csv("/cloud/project/diabetes.csv")
#Preparing data 
diabetes <- diabetes %>% 
  mutate(Outcome = factor(Outcome, levels = c(0,1), labels = c("Not Diabetes", "Diabetes")))
glimpse(diabetes)

colSums(is.na(diabetes))

#arranging data in tabular form
x <- prop.table(table(diabetes$Outcome))
b <- barplot(x,col="lightBlue", main = "Target Class Proportion Diagram")
text(x=b, y= x, labels=round(x,2), pos = 1)

RNGkind(sample.kind = "Rounding")
set.seed(23)

#Training and testing data
intrain <- sample(nrow(diabetes),nrow(diabetes)*.8)

diabetes_train <- diabetes[intrain,]
diabetes_test <- diabetes[-intrain,]

prop.table(table(diabetes_train$Outcome))

diabetes_train_x <- diabetes_train %>% select(-Outcome)
diabetes_test_x <- diabetes_test %>% select(-Outcome)

#Target
diabetes_train_y <- diabetes_train %>% select(Outcome)
diabetes_test_y <- diabetes_test %>% select(Outcome)

diabetes_train_x_scaled <- scale(x = diabetes_train_x)
diabetes_test_x_scaled <- scale(x = diabetes_test_x,
                                center = attr(diabetes_train_x_scaled,"scaled:center"),
                                scale = attr(diabetes_train_x_scaled,"scaled:scale"))

#Calculations
k <- sqrt(nrow(diabetes_train))
k~23

install.packages("class")
library(class)


diabetes_test_KNN <- diabetes_test
diabetes_test_KNN$label_predicted_KNN <- knn(train = diabetes_train_x_scaled,test = diabetes_test_x_scaled,cl = diabetes_train$Outcome,k = 23)

install.packages("caret")
library(caret)

confusionMatrix_KNN <- confusionMatrix(data = diabetes_test_KNN$label_predicted_KNN,
                                       reference = diabetes_test_KNN$Outcome,positive = "Diabetes")
confusionMatrix_KNN
