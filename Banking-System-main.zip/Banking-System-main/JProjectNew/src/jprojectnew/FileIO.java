package jprojectnew;
import java.io.*;

/**
 * @author Abhilash
 * @author Aditya
 * @author Tamizh
 * @author Lakshay
 * @author Arshdeep
 * Main class for bank program to create objects and functions 
 */

public class FileIO
{
	BufferedWriter bw; // to hold the bufferwriter object 
	BufferedReader br; //  to  hold the bufferreader object 
	
	/*
	 * Method to initialize buffered writer 
	 */
	FileIO()
	{
		try
		{
			bw=new BufferedWriter(new FileWriter("Log.txt"));
		}
		catch(IOException e)
		{
			System.out.println("Not able to create");
			System.exit(0);
		}

	}

	/*
	 * a method to write data into the file
	 * @param s to take string s 
	 * */

	void writeTofile(String s) throws IOException
	{
		bw.write(s);
	}
	
	/*
	 * Method to open and read the log file
	 * */
	
	
	void readFromFile()
	{
		try
		{
			br=new BufferedReader(new FileReader("Log.txt"));
			String str;
			while((str=br.readLine())!=null)
			{
				System.out.println(str);
			}
		}
		catch(IOException e)
		{
			System.out.println("Not able to create");
			System.exit(0);
		}

	}
	/*
	 * A method to close the buffered write 
	 * */
	
	void close() throws IOException
	{
		bw.close();
	}
}