package jprojectnew;
import java.io.IOException;
import java.util.*;
import javax.swing.JOptionPane;
/**
 * @author Abhilash
 * @author Aditya
 * @author Tamizh
 * @author Lakshay
 * @author Arshdeep
 * Methods for each functionality are defined in this class and list interface is used to do app and delate operations 
 */

public class CustomerMethod
{


     FileIO file =new FileIO(); // created a fileIO class object to read and write data into a log file
     List<CustomerDetails> list=new ArrayList<>(); // Created a list of type CustomerDetails using Array list 
     private int salary; //Holdes the number of salary accounts
     private int savings; // holdes the number of savings account
     private int current; // holdes the number of current accounts
     String writing; // hold the value of string to add into the log file

     //constructor
     
     CustomerMethod()
     {
          savings=0;
          salary=0;
          current=0;
     }
     
     /**
    	method to check if the account number is already present 
   		@param no takes the  account number
   		@return boolen value 
      */
     boolean listHas(int no)
     {
          for(CustomerDetails o:list)
          {
               if(o.getAccNo()==no)
                    return true;
          }
          return false;
     }
     /**
 		method used to  set the customer details 
		@param no account number 
		@param CustomerDetails object to set the value 
   */
     void listSet(int no,CustomerDetails d)
     {
    	 System.out.println(d);
          for(int i=0;i<list.size();i++)
          {
               CustomerDetails temp=list.get(i);
               if(temp.getAccNo()==no)
               {
                    list.set(i,d);
               }
          }
     }
     /**
      * 
      * @param no account number
      * @return temp customer details obejct value
      */
     CustomerDetails listGet(int no)
     {
          for(int i=0;i<list.size();i++)
          {
               CustomerDetails temp=list.get(i);
               if(temp.getAccNo()==no)
                    return temp;
          }
          return null;
     }



     /**
        Methed to open an  account 
         @param cname name of the customer
    	@param accNO account number 
    	@param acctype account type
    	@param amount take amount
    	@return success boolean value for status of the transaction 
     */     
     public boolean open(String cname,int accNo,String accType,double amount) throws IOException
     {
          boolean success=true;
          CustomerDetails o=new CustomerDetails(cname,accNo,accType,amount);
          list.add(o);
          JOptionPane.showMessageDialog(null,"account holder name is :" + o.getCname());
//          System.out.println(o.getCname());
          if(accType.equalsIgnoreCase("salary"))
               salary++;
          else if(accType.equalsIgnoreCase("savings"))
               savings++;
          else if(accType.equalsIgnoreCase("current"))
               current++;
          else
               success=false;
          writing=accType+" Created "+"for "+cname+" with opening amount as = "+amount+"\n Account No.= "+accNo+"\n";
          file.writeTofile(writing);
          return success;
     }
     /**
      Methed to deposit amount  into the account  
      @param no account number
 	  @param amt amount to be deposited 
 	  @return success boolean value for status of the transaction 
      */   
     public boolean deposit(int no,double amt) throws IOException
     {
          boolean success=true;
          if(listHas(no))
          {
               System.out.println("Depositing INR "+amt);
               CustomerDetails c=listGet(no);
               c.setAmount(c.getAmount()+amt);
               JOptionPane.showMessageDialog(null,"Balance after Deposit :- " +c.getAmount());
               listSet(no,c);
               writing="Updated balance for Account no. = "+c.getAccNo()+" is "+c.getAmount()+" after depositing "+amt;
               file.writeTofile(writing);
          }
          else {
        	   JOptionPane.showMessageDialog(null,"No Account exists");
//               System.out.println("No Account exists");
               success = false;
          }
          return success;
     }
     /**
     Method to withdraw amount  from the account  
     @param no account number
	  @param amt amount to be deposited 
	  @return success boolean value for status of the transaction 
     */ 
     
     public boolean witdraw(int no,double amt) throws IOException
     {
          boolean success=true;
          if(listHas(no))
          {
               CustomerDetails c=listGet(no);
               if(c.getAmount()<amt)
               {
            	   JOptionPane.showMessageDialog(null,"Low Balance");
                    System.out.println("Low Balance");
                    success=false;
               }
               else
               {
            	   JOptionPane.showMessageDialog(null,"Withdrawing INR "+amt);
//                    System.out.println("Withdrawing INR "+amt);
                    c.setAmount(c.getAmount()-amt);
                    listSet(no,c);
                    JOptionPane.showMessageDialog(null,"Current Balance after Withdrawing :- "+c.getAmount());
//                    System.out.println("Current Balance after Withdrawing :- "+c.getAmount());
               }
               writing="Updated balance for Account no. = "+c.getAccNo()+" is "+c.getAmount()+" after withdrawing "+amt;
               file.writeTofile(writing);
          }
          else {
               System.out.println("No account exists");
               success = false;
          }
          return success;
     }
     /**
     Method to check the current balance of the account
     @param no account number
	 @return success boolean value for status of the transaction 
     */ 
     public boolean currentBal(int no) throws IOException
     {
          boolean success=true;
          if(listHas(no))
          {
               CustomerDetails c=listGet(no);
//               System.out.println("Current Balance :- "+c.getAmount());
               JOptionPane.showMessageDialog(null,"Current Balance :- "+c.getAmount());
          }
          else {
        	  JOptionPane.showMessageDialog(null,"No Account with no " + no + " exists");
               success = false;
          }
          return success;
     }
     /**
     Method to transfer the amount from one accout to another
     @param from account number for first account from which the ammount has to be transferred
	 @param to account number to which  the amount has to be transferred 
	 @return success boolean value for status of the transaction 
     */
 
     public boolean transfer(int from,int to,double amt) throws IOException
     {
          boolean success=true;
          if(listHas(from) && listHas(to))
          {
               CustomerDetails f=(CustomerDetails) listGet(from);
               if(f.getAmount()>amt)
               {    
            	    JOptionPane.showMessageDialog(null,"Transferring...");
                    CustomerDetails t=(CustomerDetails)listGet(to);
                    t.setAmount(t.getAmount()+amt);
                    f.setAmount(f.getAmount()-amt);
                    listSet(from,f);
                    listSet(to,t);
                    JOptionPane.showMessageDialog(null,"Transfer Complete");
//                    System.out.println("Transfer Complete");
                    writing="Updated balance for Account no. = "+t.getAccNo()+" is "+t.getAmount()+" after depositing "+amt;
                    writing="Updated balance for Account no. = "+f.getAccNo()+" is "+f.getAmount()+" after transferring "+amt;
                    file.writeTofile(writing);
               }
               else
               {
                    success=false;
                    JOptionPane.showMessageDialog(null,from+" dosen't have enough balance");
//                    System.out.println(from+" dosen't have enough balance");
               }
          }
          else {
        	  JOptionPane.showMessageDialog(null,"Error in Enteries");
//               System.out.println("Error in Enteries");
               success = false;
          }

          return success;
     }
     
     /**
     Method to pay the utility bill
     @param no account number 
	 @param billAmt amount that has to be paid
	 @return success boolean value for status of the transaction 
     */
    
     public boolean utilityBill(int no,double billAmt) throws IOException
     {
          boolean success=true;
          if(listHas(no))
          {
        	  JOptionPane.showMessageDialog(null,"Payment Initializing...");
//               System.out.println("Payment Initializing...");
               CustomerDetails c=(CustomerDetails)listGet(no);
               c.setAmount(c.getAmount()-billAmt);
               listSet(no,c);
               JOptionPane.showMessageDialog(null,"Payment Completed");
//               System.out.println("Payment Completed");
               writing="Updated balance for Account no. = "+c.getAccNo()+" is "+c.getAmount()+" after paying bill amounting "+billAmt;
               file.writeTofile(writing);
          }
          else
               success=false;
          return success;
     }
     /**
     Method to show all the details of the account
 
     */    
     
     public void showALL() throws IOException
     {
          for (CustomerDetails cd : list)
          {
        	  JOptionPane.showMessageDialog(null,
        			  "Account No:- "+cd.getAccNo() + "\n"
        	  		+ "Name:-       "+cd.getCname() + "\n"
        	  		+ "Type:-       "+cd.getAccType() + "\n"
        	  		+ "Amount:-     "+cd.getAmount() + "\n");
//               System.out.println("Account No:- "+cd.getAccNo());
//               System.out.println("Name:-       "+cd.getCname());
//               System.out.println("Type:-       "+cd.getAccType());
//               System.out.println("Amount:-     "+cd.getAmount()+"\n");
          }
          file.close();
          file.readFromFile();

     }
}