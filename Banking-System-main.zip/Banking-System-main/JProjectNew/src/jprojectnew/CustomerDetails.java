package jprojectnew;
/**
 * @author Aditya
 */

/**
	This class represents some particular fields and methods related to an account in the bank
*/
public class CustomerDetails {
    private String cname;        //To store the name of the bank's customer
    private int accNo;           //To store the account number of the bank's customer
    private String accType;      //To store the type of account(savings/current/salary) of the bank's customer
    private double amount;       //To store the amount in the customer's bank account 

    /**
	 	Parameterised constructor to initialize the fields of class
	 */
    CustomerDetails(String cname,int accNo,String accType,double amount)
    {
        this.accNo=accNo;
        this.accType=accType;
        this.cname=cname;
        this.amount=amount;
    }
    
    /**
		The getCname method returns the Name of customer.
		@return The value in the cname field.
     */ 
    public String getCname() {
        return cname;
    }

    /**
		The setCname method stores a value in the
  		cname field.
  		@param  The value to store in cname.
     */
    public void setCname(String cname) {
        this.cname = cname;
    }

    /**
		The getAccNo method returns the Account Number.
		@return The value in the AccNo field.
     */ 
    public int getAccNo() {
        return accNo;
    }

    /**
		The setAccNo method stores a value in the
		AccNo field.
		@param  The value to store in AccNo.
    */
    public void setAccNo(int accNo) {
        this.accNo = accNo;
    }

    /**
		The getAccType method returns the Type of Account.
		@return The value in the AccType field.
     */ 
    public String getAccType() {
        return accType;
    }

    /**
		The setAccType method stores a value in the
		AccType field.
		@param  The value to store in AccType.
     */
    public void setAccType(String accType) {
        this.accType = accType;
    }

    /**
		The getAmount method returns the Amount in the account.
		@return The value in the Amount field.
     */ 
    public double getAmount() {
        return amount;
    }

    /**
		The setAmount method stores a value in the
		Amount field.
		@param  The value to store in Amount.
     */
    public void setAmount(double amount) {
        this.amount = amount;
    }

}
