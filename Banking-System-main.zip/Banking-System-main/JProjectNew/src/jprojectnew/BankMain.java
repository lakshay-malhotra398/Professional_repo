package jprojectnew;
/**
 * @author Abhilash
 * @author Aditya
 * @author Tamizh
 * @author Lakshay
 * @author Arshdeep
 * The program is used for banking functionalities like account  opening,deposits, withdraw, check balance
 * transfer funds, pay utility bills
 */

import java.util.Scanner;
import javax.swing.JOptionPane;
public class BankMain {
    static int accountNumber=999000;
    /*
	 * 
	 *  Main function where the program starts with different message and input dialogs 
	 *  creating objects to call other functions 
	 * @param args
	 */

        public static void main(String[] args) {
            int no;                                         // used to hold the account  number  
            double openingAmount,amt;                       // used to hold the opening amount and amount
            boolean check=true;                             // a flag to check if transaction is possible 
            
            String writing;                                 // created an object of type CustomerMethod
            
            CustomerMethod customer=new CustomerMethod();   // created an object of type CustomerMethod

            Scanner sc=new Scanner(System.in);
            while(true) {
                try {
                	// select the banking functionality using show Input Dialog inside try and catch block to handle exception

                    int  choice  = Integer.parseInt( JOptionPane.showInputDialog("\t 1 --> open account \n "
                    		+ "\t 2 --> deposit in account \n"
                    		+ "\t 3 --> Withdraw from account \n"
                    		+ "\t 4 --> Get balance of account \n"
                    		+ "\t 5 --> Transfer funds \n"
                    		+ "\t 6 --> Pay utility bills \n"
                    		+ "\t 7 --> exit \n"));
                    
                    //using  switch statement to select the choice
                    switch (choice) {
                    //Case1 to open account   
                    case 1:
                            accountNumber++;             // incrementing  the initialized account  number by 1 for  each  new account  request 
                            System.out.println();

                            String name = JOptionPane.showInputDialog(" \t At your service,, Opening  account \n"
                            		+ " your account number is : " + accountNumber + "\n"
                            		+ "Please enter your name ");
                            int ch = Integer.parseInt(JOptionPane.showInputDialog("which type of account you  want \n"
                            		+ "1. Savings \n"
                            		+ "2. Current \n"
                            		+ "3. Salary"));
                            String acctype="";          // used to hold the account type 
                            
                            //switch case to select the account type 
                            switch (ch) {
                                case 1:                                  
                                    openingAmount = Double.parseDouble(JOptionPane.showInputDialog("Enter the opening amount"));
                                    acctype="Savings";
                                    check = customer.open(name, accountNumber, acctype, openingAmount);
                                    break;
                                case 2:
                                	openingAmount = Double.parseDouble(JOptionPane.showInputDialog("Enter the opening amount"));
                                    acctype="Current";
                                    check = customer.open(name, accountNumber, acctype, openingAmount);
                                    break;
                                case 3:
                                	openingAmount = Double.parseDouble(JOptionPane.showInputDialog("Enter the opening amount"));
                                    acctype="Salary";
                                    check = customer.open(name, accountNumber, acctype, openingAmount);
                                    break;
                            }
                            if (check == false) {
                                JOptionPane.showMessageDialog(null,"Sorry for inconivience, Transaction failed");
                            }
                            break;
                        //Case2 for depositing amount    
                        case 2:
                
                            no = Integer.parseInt(JOptionPane.showInputDialog("Enter the account number"));
                            
                            amt = Double.parseDouble(JOptionPane.showInputDialog("Enter the amount"));
                          
                            check = customer.deposit(no, amt);
                            if (check == false) {
                            	JOptionPane.showMessageDialog(null,"Sorry for inconivience, Transaction failed");
                            }
                            break;
                        //Case3 for withdrawing amount
                        case 3:
                        	  no = Integer.parseInt(JOptionPane.showInputDialog("Enter the account number"));
                        	  amt = Double.parseDouble(JOptionPane.showInputDialog("Enter the amount"));
                           
                            check = customer.witdraw(no, amt);
                            if (check == false) {
                            	JOptionPane.showMessageDialog(null,"Sorry for inconivience, Transaction failed");
                            }
                            break;
                        //Case4 for Getting balance
                        case 4:
                        	 no = Integer.parseInt(JOptionPane.showInputDialog("Enter the account number"));
                            
                            check = customer.currentBal(no);
                            if (check == false) {
                            	JOptionPane.showMessageDialog(null,"Sorry for inconivience, Transaction failed");
                            }
                            break;
                        //Case5 for transferring funds
                        case 5:
                        	no = Integer.parseInt(JOptionPane.showInputDialog("Enter the account number from which you want to transfer"));
                        	int to = Integer.parseInt(JOptionPane.showInputDialog("Enter the account number to which you want to transfer"));
                        	amt = Double.parseDouble(JOptionPane.showInputDialog("Enter the amount"));
                           
                            check = customer.transfer(no, to, amt);
                            if (check == false) {
                            	JOptionPane.showMessageDialog(null,"Sorry for inconivience, Transaction failed");
                            }
                            break;
                        //Case6 for Pay Utility Bills
                        case 6:
                        	
                        	no = Integer.parseInt(JOptionPane.showInputDialog("Enter the account number"));
                      	  amt = Double.parseDouble(JOptionPane.showInputDialog("Enter the amount"));
                         
                            check = customer.utilityBill(no, amt);
                            if (check == false) {
                            	JOptionPane.showMessageDialog(null,"Sorry for inconivience, Transaction failed");
                            }
                            break;
                        //Case7 for Exit
                        case 7:

                            JOptionPane.showMessageDialog(null,"Exiting...");
                            customer.showALL();
                            System.exit(0);
                            break;
                        default:
                        	JOptionPane.showMessageDialog(null,"Choose the correct option\n +"
                        			+ "\\n\\n The contents of the File are :-");
                            break;
                    }
                }
                catch(Exception E)
                {
                	JOptionPane.showMessageDialog(null,"\"Invalid type, Restarting... click ok to contine");
                	
                }
            }

        }
    }